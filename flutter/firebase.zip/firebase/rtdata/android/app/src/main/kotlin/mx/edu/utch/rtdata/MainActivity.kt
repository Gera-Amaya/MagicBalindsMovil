package mx.edu.utch.rtdata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
